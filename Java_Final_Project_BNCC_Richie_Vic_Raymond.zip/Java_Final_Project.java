import java.util.*;

class Employee {
    String code, name, gender, position;
    int salary;

    public Employee(String code, String name, String gender, String position, int salary) {
        this.code = code;
        this.name = name;
        this.gender = gender;
        this.position = position;
        this.salary = salary;
    }
}

class EmployeeManager {
    List<Employee> employees = new ArrayList<>();
    Map<String, Integer> positionCount = new HashMap<>();
    Map<String, Double> bonusRates = Map.of(
        "Manager", 0.10,
        "Supervisor", 0.075,
        "Admin", 0.05
    );

    public void insertEmployee(String code, String name, String gender, String position) {
        int salary = switch (position) {
            case "Manager" -> 8000000;
            case "Supervisor" -> 6000000;
            case "Admin" -> 4000000;
            default -> throw new IllegalArgumentException("Jabatan tidak valid!");
        };

        employees.add(new Employee(code, name, gender, position, salary));
        positionCount.put(position, positionCount.getOrDefault(position, 0) + 1);
        checkBonus(position);
    }

    private void checkBonus(String position) {
        int count = positionCount.get(position);
        if (count % 3 == 0) {
            double bonus = bonusRates.get(position);
            for (Employee e : employees) {
                if (e.position.equals(position)) {
                    e.salary += e.salary * bonus;
                }
            }
            System.out.println("Bonus " + (bonus * 100) + "% telah diberikan untuk " + position);
        }
    }

    public void viewEmployees() {
        employees.sort(Comparator.comparing(e -> e.name));
        System.out.printf("%-10s %-20s %-10s %-12s %-10s\n", "Kode", "Nama", "Gender", "Jabatan", "Gaji");
        for (Employee e : employees) {
            System.out.printf("%-10s %-20s %-10s %-12s Rp %,d\n", e.code, e.name, e.gender, e.position, e.salary);
        }
    }

    public void updateEmployee(int index, String name, String gender, String position) {
        if (index < 0 || index >= employees.size()) {
            System.out.println("Index tidak valid!");
            return;
        }
        Employee e = employees.get(index);
        e.name = name;
        e.gender = gender;
        e.position = position;
        System.out.println("Data karyawan berhasil diperbarui!");
    }

    public void deleteEmployee(int index) {
        if (index < 0 || index >= employees.size()) {
            System.out.println("Index tidak valid!");
            return;
        }
        employees.remove(index);
        System.out.println("Data karyawan berhasil dihapus!");
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmployeeManager manager = new EmployeeManager();

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Insert Data Karyawan");
            System.out.println("2. View Data Karyawan");
            System.out.println("3. Update Data Karyawan");
            System.out.println("4. Delete Data Karyawan");
            System.out.println("5. Exit");
            System.out.print("Pilih menu: ");
            int choice = sc.nextInt(); sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Kode Karyawan: ");
                    String code = sc.nextLine();
                    System.out.print("Nama Karyawan: ");
                    String name = sc.nextLine();
                    System.out.print("Jenis Kelamin (Laki-laki/Perempuan): ");
                    String gender = sc.nextLine();
                    System.out.print("Jabatan (Manager/Supervisor/Admin): ");
                    String position = sc.nextLine();
                    manager.insertEmployee(code, name, gender, position);
                }
                case 2 -> manager.viewEmployees();
                case 3 -> {
                    manager.viewEmployees();
                    System.out.print("Masukkan nomor yang ingin diupdate: ");
                    int index = sc.nextInt(); sc.nextLine();
                    System.out.print("Nama baru: ");
                    String name = sc.nextLine();
                    System.out.print("Jenis Kelamin baru: ");
                    String gender = sc.nextLine();
                    System.out.print("Jabatan baru: ");
                    String position = sc.nextLine();
                    manager.updateEmployee(index - 1, name, gender, position);
                }
                case 4 -> {
                    manager.viewEmployees();
                    System.out.print("Masukkan nomor yang ingin dihapus: ");
                    int index = sc.nextInt();
                    manager.deleteEmployee(index - 1);
                }
                case 5 -> {
                    System.out.println("Program selesai.");
                    sc.close();
                    return;
                }
                default -> System.out.println("Pilihan tidak valid!");
            }
        }
    }
}
